# PRP-001: Foundation - Supabase + Auth + Layout + Dashboard

> **Estado**: PENDIENTE
> **Fecha**: 2026-03-26
> **Proyecto**: Laboratorio de Contenido 3.0

---

## Objetivo

Construir la base completa de la aplicacion: migrar las tablas de Supabase al modelo definitivo de BUSINESS_LOGIC.md con RLS, implementar autenticacion completa (login/signup/logout con email+password), el layout principal con sidebar + topbar en estetica liquid glass negro/rojo, y el Dashboard de contenido con KPIs reales calculados desde Supabase.

## Por Que

| Problema | Solucion |
|----------|----------|
| Las tablas actuales en Supabase estan incompletas y no coinciden con el modelo de negocio (faltan bio_entries, referral_entries, deferred_entries, master_lists, account_metrics; content_items tiene columnas planas en vez de jsonb) | Migrar a esquema completo de BUSINESS_LOGIC.md con todas las tablas + RLS uniforme |
| No hay auth implementado - las paginas de login/signup son placeholders vacios | Auth funcional con Supabase: registro, login, logout, proteccion de rutas, profile auto-creado |
| No hay layout de app - solo un div vacio sin navegacion | Sidebar fija (240px) + topbar con liquid glass negro/rojo, navegacion completa a todas las secciones |
| El dashboard es un placeholder sin datos | Dashboard de contenido con KPIs reales: cash total, chats total, piezas, CPC, breakdown por canal, comparacion vs mes anterior |

**Valor de negocio**: Sin foundation no hay app. Esta fase desbloquea TODAS las features posteriores. El usuario ve datos reales desde el dia 1.

## Que

### Criterios de Exito
- [ ] Las 10 tablas de BUSINESS_LOGIC.md existen en Supabase con columnas correctas y RLS habilitado (SELECT/INSERT/UPDATE/DELETE con auth.uid() = user_id)
- [ ] Un usuario puede registrarse, loguearse, y cerrar sesion con email/password
- [ ] Las rutas (main) redirigen a /login si no hay sesion; las rutas (auth) redirigen a /dashboard si hay sesion
- [ ] El layout tiene sidebar funcional (240px, iconos, navegacion) + topbar con nombre del usuario y logout
- [ ] El dashboard muestra 4 KPI cards reales (Cash Total, Chats Total, Piezas, CPC) calculados desde content_items del mes actual
- [ ] El dashboard muestra breakdown por canal (Reels, Historias, BIO) con chats y cash por cada uno
- [ ] `npm run build` pasa sin errores
- [ ] `npm run typecheck` pasa (si se configura script)

### Comportamiento Esperado (Happy Path)

1. Usuario abre la app -> ve la pagina de Login (liquid glass, dark mode)
2. Hace click en "Crear cuenta" -> va a Signup -> ingresa email y password -> se crea cuenta + profile en Supabase
3. Es redirigido al Dashboard -> ve sidebar a la izquierda con navegacion a todas las secciones
4. En el Dashboard ve 4 KPI cards: Cash Total ($0), Chats Total (0), Piezas (0), CPC ($0) - todo en cero porque es nuevo
5. Ve seccion de breakdown por canal (Reels, Historias, BIO) - todo en cero
6. Puede hacer logout desde la topbar -> vuelve a Login

---

## Contexto

### Referencias
- `BUSINESS_LOGIC.md` - Modelo de datos completo (10 tablas), design system, KPIs
- `src/lib/supabase/client.ts` - Cliente browser ya configurado (@supabase/ssr)
- `src/lib/supabase/server.ts` - Cliente server ya configurado
- `src/app/(auth)/` - Rutas auth existentes (placeholders)
- `src/app/(main)/` - Rutas main existentes (placeholders)
- `src/features/auth/` - Feature auth scaffolded (carpetas vacias con .gitkeep)
- `src/features/dashboard/` - Feature dashboard scaffolded (carpetas vacias con .gitkeep)

### Estado Actual de Supabase

Tablas que YA existen (pero necesitan migracion):
- `profiles` - Existe, le faltan campos vs BUSINESS_LOGIC (tiene brand_name, avatar_url, timezone que no estan en el spec - mantener ya que son utiles)
- `content_items` - Existe pero con esquema diferente: tiene columnas planas (views, likes, etc) en vez de jsonb metrics/classification. Tambien tiene campos extra (dolor, angulo, formato, cta, engagement_rate, description, thumbnail_url). Necesita migracion a esquema BUSINESS_LOGIC
- `leads` - Existe pero MUY simplificado: solo tiene client_name, amount, date, source_type, channel, notes, setter, closer. Faltan 15+ columnas del spec
- `team_members` - Existe con esquema diferente: tiene metas (meta_llamadas, etc) y comision_pct en vez de commission_type + commission_tiers jsonb
- `api_connections` - Existe pero esquema diferente: tiene provider en vez de platform, access_token/refresh_token en vez de credentials jsonb
- `objectives` - Existe pero simplificado: month es date en vez de text, solo tiene target_cash/chats/content
- `daily_calls` - Existe (NO esta en BUSINESS_LOGIC.md - tabla extra)

Tablas que FALTAN:
- `bio_entries`
- `referral_entries`
- `deferred_entries`
- `master_lists`
- `account_metrics`

### Arquitectura Propuesta (Feature-First)

```
src/
├── app/
│   ├── (auth)/
│   │   ├── layout.tsx          # Layout auth centrado, dark mode
│   │   ├── login/page.tsx      # Login form
│   │   └── signup/page.tsx     # Signup form
│   ├── (main)/
│   │   ├── layout.tsx          # Layout con Sidebar + Topbar
│   │   └── dashboard/page.tsx  # Dashboard de contenido
│   ├── auth/callback/route.ts  # Callback handler de Supabase
│   └── layout.tsx              # Root layout (fonts, globals)
│
├── features/
│   ├── auth/
│   │   ├── components/
│   │   │   ├── login-form.tsx
│   │   │   └── signup-form.tsx
│   │   ├── hooks/
│   │   │   └── use-auth.ts
│   │   └── services/
│   │       └── auth-service.ts
│   │
│   └── dashboard/
│       ├── components/
│       │   ├── kpi-card.tsx
│       │   ├── kpi-grid.tsx
│       │   └── channel-breakdown.tsx
│       ├── hooks/
│       │   └── use-dashboard-data.ts
│       ├── services/
│       │   └── dashboard-service.ts
│       └── types/
│           └── dashboard.ts
│
├── shared/
│   ├── components/
│   │   ├── sidebar.tsx
│   │   ├── topbar.tsx
│   │   └── glass-card.tsx
│   └── lib/
│       └── supabase/
│           ├── client.ts       # Ya existe
│           ├── server.ts       # Ya existe
│           └── middleware.ts    # Auth middleware
│
└── middleware.ts                # Next.js middleware para proteccion de rutas
```

### Modelo de Datos (Migracion)

La estrategia es: crear las tablas faltantes nuevas, y migrar las existentes para que coincidan con BUSINESS_LOGIC.md. Se debe tener cuidado con los datos existentes (profiles tiene 2 rows, leads tiene 1 row, team_members tiene 4 rows, daily_calls tiene 2 rows).

**Decision clave**: content_items tiene 0 rows, asi que se puede hacer DROP + recreate sin perder datos. Para leads y team_members con datos, se hace ALTER TABLE para agregar/modificar columnas.

Las 10 tablas finales con RLS:
1. `profiles` (mantener + agregar campos si faltan)
2. `content_items` (recrear con esquema BUSINESS_LOGIC: metrics jsonb, classification jsonb, cash, chats, platform, content_type)
3. `leads` (ALTER: agregar ig_handle, phone, avatar_type, status con CHECK, entry_funnel, agenda_point, ctas_responded, first_contact_at, scheduled_at, call_at, call_link, closer_report, program_offered, program_purchased, revenue, payment, owed)
4. `bio_entries` (crear nueva)
5. `referral_entries` (crear nueva)
6. `deferred_entries` (crear nueva)
7. `team_members` (ALTER: agregar commission_type, commission_tiers jsonb, is_active; adaptar existentes)
8. `objectives` (ALTER: agregar views_target, followers_target, pieces_target, scenario; cambiar month a text)
9. `api_connections` (ALTER: renombrar provider->platform, unificar tokens en credentials jsonb)
10. `master_lists` (crear nueva)
11. `account_metrics` (crear nueva)

**Nota**: `daily_calls` se mantiene como tabla extra (tiene datos, puede ser util).

### Design System: Liquid Glass Negro + Rojo

Definido en BUSINESS_LOGIC.md:
- **Background**: #050505 (negro profundo)
- **Accent**: #E63946 (rojo marca)
- **Texto**: #FAFAFA (blanco) con jerarquia en grises
- **Semantico**: #22C55E (verde/cash), #F59E0B (amber/warning)
- **Glass**: backdrop-filter blur(12px) + bg-white/5 + border border-white/10 + shadow
- **Tipografia**: Inter (UI) + JetBrains Mono (numeros/metricas)
- **Sidebar**: 240px fija

---

## Blueprint (Assembly Line)

> IMPORTANTE: Solo definir FASES. Las subtareas se generan al entrar a cada fase.

### Fase 1: Migracion de Base de Datos
**Objetivo**: Todas las tablas de BUSINESS_LOGIC.md existen en Supabase con el esquema correcto, RLS habilitado, y policies CRUD con auth.uid() = user_id
**Validacion**:
- `list_tables` muestra las 11 tablas (10 de BUSINESS_LOGIC + daily_calls)
- Todas tienen rls_enabled = true
- Columnas coinciden con el spec de BUSINESS_LOGIC.md

### Fase 2: Autenticacion Completa
**Objetivo**: Login, signup, logout funcionales con email/password. Middleware protege rutas. Profile se crea automaticamente al registrarse. Redirect inteligente (auth->dashboard si logueado, main->login si no).
**Validacion**:
- Registrar nuevo usuario -> profile creado en tabla profiles
- Login con credenciales -> redirige a /dashboard
- Acceder a /dashboard sin sesion -> redirige a /login
- Logout -> sesion destruida, redirige a /login

### Fase 3: Layout Principal (Sidebar + Topbar)
**Objetivo**: Layout con sidebar fija de 240px con navegacion a todas las secciones de la app, topbar con nombre de usuario y boton logout. Todo con estetica liquid glass negro/rojo.
**Validacion**:
- Sidebar visible con iconos y labels para: Dashboard, Contenido (sub: Reels, Historias, YouTube), Leads, Ventas, Equipo, Canales Directos (sub: BIO, Referidos, Diferidos), Objetivos, Cash Metrics, Conexiones API, Listas Maestras, Configuracion
- Topbar muestra nombre del usuario logueado + boton logout funcional
- Estetica liquid glass: fondo negro, cards con blur, accent rojo, tipografia Inter + JetBrains Mono

### Fase 4: Dashboard de Contenido con KPIs Reales
**Objetivo**: Dashboard que muestra KPIs calculados en tiempo real desde Supabase: Cash Total, Chats Total, Piezas publicadas, CPC (Cash Per Chat), con breakdown por canal (Reels, Historias, BIO) y comparacion vs mes anterior.
**Validacion**:
- 4 KPI cards muestran datos reales del mes actual (query a content_items + bio_entries + referral_entries)
- Breakdown por canal muestra chats y cash separados por Reels, Historias, BIO
- Si no hay datos, muestra $0 / 0 (no errores)
- Los numeros usan JetBrains Mono, las cards tienen glass effect

### Fase 5: Validacion Final
**Objetivo**: Sistema funcionando end-to-end, build limpio, todo integrado
**Validacion**:
- [ ] `npm run build` exitoso
- [ ] Flujo completo: signup -> dashboard con KPIs -> navegacion sidebar -> logout -> login
- [ ] RLS funciona: un usuario solo ve sus datos
- [ ] Criterios de exito del PRP cumplidos

---

## Aprendizajes (Self-Annealing)

> Esta seccion CRECE con cada error encontrado durante la implementacion.

*(Vacio - se llena durante la implementacion)*

---

## Gotchas

- [ ] Supabase @supabase/ssr requiere middleware de Next.js para refresh de tokens - NO olvidar crear middleware.ts en root
- [ ] Las tablas con datos existentes (leads: 1 row, team_members: 4 rows, profiles: 2 rows) necesitan ALTER TABLE, no DROP+CREATE
- [ ] content_items tiene 0 rows - se puede hacer DROP y recrear sin riesgo
- [ ] El trigger para crear profile automaticamente en signup necesita una function en Supabase (handle_new_user)
- [ ] Next.js 16 + Turbopack: verificar compatibilidad de fonts (Inter, JetBrains Mono) con next/font
- [ ] RLS policies deben cubrir los 4 operations (SELECT, INSERT, UPDATE, DELETE) - no olvidar ninguno
- [ ] Chart.js / Recharts requieren dynamic import en Next.js por SSR (no aplica en Fase 1, pero tener en cuenta para sparklines futuras)
- [ ] Interfaz 100% en espanol segun BUSINESS_LOGIC.md

## Anti-Patrones

- NO crear nuevos patrones si los existentes funcionan
- NO ignorar errores de TypeScript
- NO hardcodear valores (usar constantes)
- NO omitir validacion Zod en inputs de usuario (forms de auth)
- NO usar localStorage como storage - Supabase es source of truth
- NO exponer Supabase service_role key en el cliente
- NO hacer queries sin filtro de user_id (RLS es backup, no reemplazo)

---

*PRP pendiente aprobacion. No se ha modificado codigo.*
