# PRP-002: Auditoria e Integracion Leads-Dashboards

> **Estado**: PENDIENTE
> **Fecha**: 2026-03-27
> **Proyecto**: Laboratorio de Negocio

---

## Objetivo

Auditar y conectar la tabla `leads` con todos los dashboards del sistema, mapeando flujos de datos existentes, identificando conexiones rotas o faltantes, y creando un servicio centralizado que alimente todos los dashboards desde una unica fuente de verdad.

## Por Que

| Problema | Solucion |
|----------|----------|
| El dashboard principal (`/dashboard`) NO consume datos de `leads` — solo usa `content_items`, `bio_entries`, `referral_entries` y `deferred_entries` para cash/chats | Integrar metricas de ventas (cierres, revenue, payment) de `leads` al dashboard principal |
| El sales-dashboard (`/sales-dashboard`) SI consume `leads` pero calcula "conversaciones" sumando chats de `content_items` + `bio_entries`, sin conexion directa lead-a-contenido | Crear link explicito entre leads y su canal de origen para atribucion real |
| Los dashboards de setter/closer (`/setter`, `/closer`) consumen `leads` correctamente pero duplican la logica de calculo (agendas, shows, cierres) en cada componente | Centralizar calculos en un servicio compartido |
| No hay flujo de datos de `leads` hacia `cash-metrics` ni `objetivos` — estos solo miran `content_items`, `bio_entries`, y `referral_entries` | Agregar datos de ventas cerradas de leads a cash-metrics y objetivos |
| El campo `leads.revenue` (facturacion) y `leads.payment` (cash collected) existen pero no alimentan las metricas de cash del dashboard principal | Unificar la definicion de "cash" entre dashboards para evitar discrepancias |

**Valor de negocio**: Vision unificada del embudo completo (contenido → chat → lead → venta → cash) en un solo lugar. Eliminar discrepancias entre dashboards que causan decisiones erroneas.

## Que

### Criterios de Exito
- [ ] El dashboard principal (`/dashboard`) muestra metricas de ventas derivadas de `leads` (cierres, revenue, ticket promedio)
- [ ] Existe un unico servicio (`leads-analytics-service.ts`) que centraliza todos los calculos de leads para evitar duplicacion
- [ ] La pagina de objetivos (`/objetivos`) incluye metas de ventas (cierres, revenue) ademas de contenido
- [ ] Cash-metrics (`/cash-metrics`) integra el cash collected de leads cerrados
- [ ] Los dashboards de setter/closer usan el servicio centralizado en vez de calculos inline
- [ ] `npm run typecheck` pasa sin errores
- [ ] `npm run build` exitoso

### Comportamiento Esperado

**Happy Path:**
1. Usuario carga un lead en `/leads` con status "Cerrado", payment: $5000, program: "Boost"
2. En `/dashboard`, el cash collected del mes sube $5000 y aparece una nueva seccion de "Ventas" mostrando cierres, ticket promedio, y close rate
3. En `/sales-dashboard`, los datos son consistentes con `/dashboard` — mismas cifras de revenue
4. En `/cash-metrics`, el lead cerrado aparece como fuente de cash con atribucion al canal de origen
5. En `/objetivos`, hay una nueva meta de "Cash por Ventas" y "Cierres" con barra de progreso
6. En `/setter` y `/closer`, los calculos son identicos a los del sales-dashboard (misma fuente)

---

## Contexto

### Mapa de Flujo de Datos Actual

```
TABLAS SUPABASE                    DASHBOARDS QUE LA CONSUMEN
─────────────────                  ──────────────────────────
leads (40 rows)                    → /sales-dashboard (SI - directo)
  - status, payment, revenue       → /setter, /closer (SI - directo)
  - setter, closer                 → /dashboard (NO - desconectado)
  - scheduled_at, call_at          → /cash-metrics (NO - desconectado)
  - program_purchased              → /objetivos (NO - desconectado)
  - month, entry_channel

content_items (82 rows)            → /dashboard (SI - cash, chats, piezas)
  - cash, chats, content_type      → /sales-dashboard (SI - solo chats para "conversaciones")
  - published_at                   → /cash-metrics (SI - ranking de piezas)
                                   → /objetivos (SI - piezas, cash, chats)

bio_entries (4 rows)               → /dashboard (SI - cash, chats)
  - cash, chats, month             → /sales-dashboard (SI - solo chats)
                                   → /cash-metrics (SI)
                                   → /objetivos (SI - cash, chats)

referral_entries (0 rows)          → /dashboard (SI - cash, chats)
  - cash, chats, month             → /cash-metrics (SI)

deferred_entries (0 rows)          → /dashboard (SI - cash)
  - cash, month

manychat_chats (1 row)             → /dashboard (SI - conteo como chats BIO)
  - month                          → /sales-dashboard (SI - conteo para conversaciones)

account_metrics (0 rows)           → /dashboard (SI - views, followers)
  - account_views, followers       → /objetivos (SI - views)

objectives (0 rows)                → /dashboard (SI - targets)
  - cash_target, chats_target      → /objetivos (SI - targets editables)

team_members (2 rows)              → /leads (SI - nombres setter/closer)
  - name, role                     → /setter, /closer (SI - filtro por role)
```

### Problemas Identificados

1. **Dashboard principal ignora leads**: El `/dashboard` calcula cash solo desde content_items + bio + referrals + deferred. Los leads cerrados con payment NO se reflejan ahi.

2. **Doble conteo potencial**: Si un reel genera cash=500 (en content_items) Y un lead cerrado tiene payment=500 (en leads), son la misma venta o diferente? No hay FK ni referencia cruzada.

3. **Logica duplicada**: `sales-dashboard-page.tsx` (lineas 37-83), `role-metrics-page.tsx` (lineas 57-73), y la tabla de leads calculan agendas/shows/cierres de forma independiente con logica similar pero no identica.

4. **"Conversaciones" en sales-dashboard es artificial**: Se calcula sumando chats de content_items + bio_entries, no son leads reales que iniciaron conversacion.

5. **Cash-metrics no tiene vision de ventas**: Solo rankea piezas de contenido por cash/chats, pero no muestra que leads cerraron ni que programas se vendieron.

### Referencias
- `src/features/leads/types/index.ts` — Tipo Lead con 28 campos
- `src/features/leads/components/leads-page.tsx` — Tabla principal de leads
- `src/features/dashboard/services/dashboard-service.ts` — Servicio del dashboard (server-side, no usa leads)
- `src/features/sales-dashboard/components/sales-dashboard-page.tsx` — Dashboard ventas (client-side, SI usa leads)
- `src/features/team/components/role-metrics-page.tsx` — Metricas setter/closer (client-side, usa leads)
- `src/app/(main)/dashboard/page.tsx` — Dashboard principal (client-side, NO usa leads)
- `src/app/(main)/cash-metrics/page.tsx` — Cash metrics (client-side, NO usa leads)
- `src/app/(main)/objetivos/page.tsx` — Objetivos (client-side, NO usa leads)

### Arquitectura Propuesta

```
src/features/leads/
├── components/
│   └── leads-page.tsx          (existente — no tocar)
├── services/
│   └── leads-analytics.ts      (NUEVO — servicio centralizado)
├── types/
│   └── index.ts                (existente — agregar tipos analytics)
└── hooks/
    └── use-leads-analytics.ts   (NUEVO — hook client-side)
```

**Servicio centralizado `leads-analytics.ts`**:
- Funcion `getLeadsAnalytics(month)` que retorna: cierres, revenue, payment, ticket promedio, close rate, show rate, tasa agendamiento, by-setter, by-closer, by-program
- Funcion `getLeadsFunnel(month)` que retorna los datos del embudo
- Usado por: sales-dashboard, setter, closer, dashboard, cash-metrics, objetivos

### Modelo de Datos

No se requieren cambios en la BD. La tabla `leads` ya tiene todos los campos necesarios:
- `status` (Cerrado, No show, etc.)
- `payment` (cash collected)
- `revenue` (facturacion total)
- `program_purchased`
- `scheduled_at`, `call_at` (para calcular agendas/shows)
- `setter`, `closer`
- `entry_channel` (para atribucion)
- `month` (para filtro temporal)

---

## Blueprint (Assembly Line)

### Fase 1: Servicio Centralizado de Analytics de Leads
**Objetivo**: Crear `leads-analytics.ts` con todas las funciones de calculo que actualmente estan duplicadas en sales-dashboard y role-metrics, mas un hook `use-leads-analytics.ts` para consumo client-side.
**Validacion**: El servicio exporta funciones tipadas que retornan los mismos numeros que el sales-dashboard actual para un mes dado.

### Fase 2: Migrar Sales-Dashboard y Role-Metrics al Servicio
**Objetivo**: Reemplazar la logica inline de `sales-dashboard-page.tsx` (buildVD) y `role-metrics-page.tsx` (calc) para que consuman el servicio centralizado.
**Validacion**: Los dashboards /sales-dashboard, /setter y /closer muestran exactamente los mismos datos que antes — zero regression.

### Fase 3: Integrar Leads en Dashboard Principal
**Objetivo**: Agregar una seccion de "Ventas" al dashboard principal (`/dashboard`) que muestre cierres, revenue, ticket promedio, y close rate usando datos de leads.
**Validacion**: El dashboard principal muestra datos de ventas consistentes con /sales-dashboard.

### Fase 4: Integrar Leads en Cash-Metrics y Objetivos
**Objetivo**: Agregar leads cerrados como fuente de cash en `/cash-metrics` y crear metas de ventas en `/objetivos` (cierres target, revenue target).
**Validacion**: Cash-metrics muestra piezas de contenido Y leads cerrados. Objetivos tiene barras de progreso para metas de ventas.

### Fase 5: Validacion Final
**Objetivo**: Sistema funcionando end-to-end con datos consistentes entre todos los dashboards.
**Validacion**:
- [ ] `npm run typecheck` pasa
- [ ] `npm run build` exitoso
- [ ] Todos los dashboards muestran datos consistentes para el mismo mes
- [ ] No hay logica de calculo duplicada fuera del servicio centralizado
- [ ] Criterios de exito cumplidos

---

## Aprendizajes (Self-Annealing / Neural Network)

> Esta seccion CRECE con cada error encontrado durante la implementacion.

---

## Gotchas

- [ ] El dashboard principal usa `useSupabase()` (client-side) pero tambien tiene `dashboard-service.ts` (server-side con `createClient` de server). Decidir si el nuevo servicio es client o server.
- [ ] Posible doble conteo: cash de content_items vs payment de leads. Necesita definicion clara: son fuentes separadas o la misma venta trackeable desde dos angulos?
- [ ] `sales-dashboard` calcula "conversaciones" desde content_items chats + bio chats, no desde leads count. Al integrar, mantener esta definicion o cambiarla?
- [ ] Los datos semanales/diarios en sales-dashboard usan `distribute()` (distribucion uniforme artificial). El servicio centralizado deberia hacer lo mismo o calcular desde fechas reales?

## Anti-Patrones

- NO crear nuevos patrones si los existentes funcionan
- NO ignorar errores de TypeScript
- NO hardcodear valores (usar constantes)
- NO duplicar logica de calculo — todo debe pasar por el servicio centralizado
- NO mezclar server-side y client-side queries sin razon — elegir un patron y ser consistente

---

*PRP pendiente aprobacion. No se ha modificado codigo.*
